package com.company;

import java.io.IOException;

/**
 *  Klasa glowna main odpowiedzialna za uruchomienie aplikacji.
 */


public class Main {

    public static void main(String[] args) {
        Controller controller = new Controller();
        controller.ShowMenu();
    }
}
